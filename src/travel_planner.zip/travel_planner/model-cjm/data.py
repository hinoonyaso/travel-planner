import json
from pathlib import Path
from datasets import Dataset

from travel_planner.model_cjm.prompt import build_prompt


def read_jsonl(path: Path) -> list[dict]:

    with path.open(encoding="utf-8") as file:
        return [json.loads(line) for line in file if line.strip()]


def serialize_label(label: dict) -> str:
    return json.dumps(
        label,
        ensure_ascii=False,
        separators=(",", ":"),
    )


def to_sft_example(record: dict) -> dict:
    prompt = build_prompt(
        category=record["category"],
        review=record["review"],
    )

    completion = serialize_label(record["label"])

    return {
        "prompt": prompt,
        "completion": [
            {
                "role": "assistant",
                "content": completion,
            }
        ],
    }


def build_train_validation_records(
    silver_file: Path,
    split_file: Path,
) -> tuple[list[dict], list[dict]]:
    silver_records = read_jsonl(silver_file)
    split = json.loads(split_file.read_text(encoding="utf-8"))

    train_records = []
    validation_records = []

    for record in silver_records:
        place_id = record["place_id"]
        place_split = split.get(place_id)

        if place_split == "train":
            train_records.append(record)
        elif place_split == "val":
            validation_records.append(record)
        elif place_split == "test":
            continue
        else:
            raise ValueError(f"split.json에 없는 place_id입니다: {place_id}")

    return train_records, validation_records


def build_test_records(gold_file: Path) -> list[dict]:
    records = read_jsonl(gold_file)

    for record in records:
        if record.get("tier") != "gold":
            raise ValueError(
                f"Gold test 파일에 Gold가 아닌 레코드가 있습니다: {record['review_id']}"
            )

    return records


def remove_duplicate_reviews(records: list[dict]) -> list[dict]:
    seen: set[tuple[str, str]] = set()
    unique_records = []

    for record in records:
        key = (
            record["place_id"],
            record["review"].strip(),
        )

        if key in seen:
            continue

        seen.add(key)
        unique_records.append(record)

    return unique_records


def convert_to_dataset(records: list[dict]) -> Dataset:
    examples = [to_sft_example(record) for record in records]

    return Dataset.from_list(examples)


def load_training_datasets(
    silver_file: Path,
    split_file: Path,
    gold_file: Path,
):
    train_records, validation_records = build_train_validation_records(
        silver_file=silver_file,
        split_file=split_file,
    )

    train_records = remove_duplicate_reviews(train_records)
    validation_records = remove_duplicate_reviews(validation_records)

    test_records = build_test_records(gold_file)

    train_dataset = convert_to_dataset(train_records)
    validation_dataset = convert_to_dataset(validation_records)

    return (
        train_dataset,
        validation_dataset,
        test_records,
    )
